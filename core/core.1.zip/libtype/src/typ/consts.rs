pub static EMPTY_TYPE: &'static str = "()";
pub static ANY_TYPE: &'static str = "any";
pub static NULL_TYPE: &'static str = "null";
