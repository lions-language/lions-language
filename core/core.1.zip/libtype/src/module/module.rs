use crate::module::{Module};

impl Module {
    pub fn to_str(&self) -> &str {
        &self.name
    }
}

