pub static OPERATOR_PLUS_FUNCTION_NAME: &'static str = "+";
pub static TO_STR_FUNCTION_NAME: &'static str = "to_str";
pub static PRIMEVAL_FUNCTION_PRINTLN: &'static str = "println";
