use libmacro_test::field_get;
use libmacro_test::field_new;

fn main() {
    field_get::test();
    // field_new::test();
}
