pub struct FuncToBeFilled {
}

impl FuncToBeFilled {
    pub fn is_exist_filled(&self) -> bool {
        false
    }

    pub fn new() -> Self {
        Self {
        }
    }
}
