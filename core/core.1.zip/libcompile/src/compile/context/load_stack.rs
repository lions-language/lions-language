use libtype::{Data, AddressKey};
use crate::compile::{LoadStackContext};

impl LoadStackContext {
}
