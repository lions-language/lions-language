pub mod strcompare;
