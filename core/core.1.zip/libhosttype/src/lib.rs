#![feature(proc_macro_hygiene)]

#[macro_use]
extern crate lazy_static;

pub mod primeval;
pub mod number;
pub mod string;
