pub enum DescResult {
    Success,
    Error(String)
}

pub mod function;
